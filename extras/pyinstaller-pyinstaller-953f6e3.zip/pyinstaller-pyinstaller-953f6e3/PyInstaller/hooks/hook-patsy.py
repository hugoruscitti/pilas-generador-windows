
hiddenimports = ['patsy.builtins']
