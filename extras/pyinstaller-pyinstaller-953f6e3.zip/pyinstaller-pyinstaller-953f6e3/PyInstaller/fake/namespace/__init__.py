# This is an empty source file, required for faking
# namespace-packages. It has to be named __init__.py, since
# pyi_archive.zlibArchive.add() takes that as a marker for packages.
